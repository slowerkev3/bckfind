import requests
import os
import sys
if os.name == "nt":
	os.system("cls")
	os.system("title ServerScan / Coded by llslowll")
else:
	os.system("clear")
print("""


    .____    .__         .__                .__  .__    >#######################################################
    |    |   |  |   _____|  |   ______  _  _|  | |  |   > Bu Arac llslowll Tarafından Kodlanmıştır Yani Ben.   #
    |    |   |  |  /  ___/  |  /  _ \ \/ \/ /  | |  |   > İnstagram -> mehmetali_altnyzk                       #
    |    |___|  |__\___ \|  |_(  <_> )     /|  |_|  |__ >#######################################################
    |_______ \____/____  >____/\____/ \/\_/ |____/____/
        \/         \/                              

""")
try:
	urller = sys.argv[1]
	adminlist = sys.argv[2]
	bftimeout = sys.argv[3]
	kaydet = sys.argv[4]
	try:
		ac = open(urller, 'r').readlines()
		ac1 = open(adminlist, 'r').readlines()
		print(" [+] Sikis Basladi!")
		print("")
	except:
		print("")
		print(" [-] Dosyalar bulunamadi!")
		sys.exit()
		print("")
	for url in ac:
		url = url.rstrip()
		for admin in ac1:
			admin = admin.rstrip()
			os.system("title " + "Taraniyor " + url + admin)
			try:
				r = requests.get(url + admin, timeout=float(bftimeout))
				if r.status_code == 200:
                                        print("Bulundu "+url+admin+" -> Status Code "+r.status_code)

			except:
				break
	print("")
	print(" [+] Tarama bitti!")
except:
	print(" [!] Kullanim sekli ---> python serverscan.py sitelist.txt adminlist.txt 100 E")
	sys.exit()
